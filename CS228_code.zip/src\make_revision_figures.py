"""
make_revision_figures.py — Plot the revision-round results.

Reads:
    results/block_cv_weekly.csv  results/block_cv.csv
    results/minimal_weekly.csv   results/minimal.csv

Writes:
    results/figures/fig_block_cv.png   (+ .pdf)     2-panel: weekly | short
    results/figures/fig_minimal.png    (+ .pdf)     2-panel: weekly | short

Run:
    python src/make_revision_figures.py
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import rcParams

# project palette (same as make_ablation_figures.py)
INK    = "#1F2A37"
SLATE  = "#6B7C8F"
AMBER  = "#D99A2B"
TEAL   = "#2E8B8B"
GRID   = "#D7DDE3"

rcParams.update({
    # NeurIPS / arXiv-style serif (Times-like, paper-aesthetic).
    # Falls back across Win/Mac/Linux: Times → STIX → DejaVu Serif.
    "font.family":      "serif",
    "font.serif":       ["Times New Roman", "Times", "STIXGeneral",
                          "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size":        11,
    "axes.titlesize":   12,
    "axes.labelsize":   11,
    "xtick.labelsize":  10,
    "ytick.labelsize":  10,
    "legend.fontsize":  10,
    "savefig.dpi":      300,
    "savefig.bbox":     "tight",
})

RESULTS = "results"
FIGDIR  = os.path.join(RESULTS, "figures")
os.makedirs(FIGDIR, exist_ok=True)


def _save(fig, stem):
    for ext in ("png", "pdf"):
        out = os.path.join(FIGDIR, f"{stem}.{ext}")
        fig.savefig(out)
        print(f"  → {out}")


def _style(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(SLATE)
    ax.spines["bottom"].set_color(SLATE)
    ax.tick_params(colors=INK, labelsize=10)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


# ────────────────────────────────────────────────────────────
# 1) Block-CV: 4 chronological folds × 3 models, per task
# ────────────────────────────────────────────────────────────
def fig_block_cv():
    df_w = pd.read_csv(os.path.join(RESULTS, "block_cv_weekly.csv"))
    df_s = pd.read_csv(os.path.join(RESULTS, "block_cv.csv"))

    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.2))

    for ax, df, title, units in [
        (axes[0], df_w, "Weekly task ($H{=}168$)",  "Wh/h"),
        (axes[1], df_s, "Short task ($H{=}24$)",    "Wh"),
    ]:
        folds = ["fold1", "fold2", "fold3", "fold4"]
        models = ["dlinear", "itransformer", "tcdpmixer"]
        colors = [SLATE, TEAL, AMBER]
        labels = ["DLinear", "iTransformer", "TC-DPMixer (ours)"]

        x = np.arange(len(folds))
        w = 0.27
        for i, (m, c, lab) in enumerate(zip(models, colors, labels)):
            vals = [df[(df.fold == f) & (df.model == m)].test_MAE.iloc[0]
                    for f in folds]
            ax.bar(x + (i - 1) * w, vals, w, color=c, label=lab,
                   edgecolor=INK, linewidth=0.4)

        ax.set_title(title, color=INK, fontsize=12, pad=8)
        ax.set_xticks(x)
        ax.set_xticklabels([f"55/15/30", "60/15/25", "65/15/20",
                            "70/15/15\n(ref.)"], fontsize=9)
        ax.set_xlabel("train / val / test ratio", color=INK, fontsize=10)
        ax.set_ylabel(f"Test MAE ({units})", color=INK, fontsize=10)
        _style(ax)

        # annotate the gap (iTrans − TC) just above the TC bar
        if df is df_w:
            for k, f in enumerate(folds):
                it = df[(df.fold == f) & (df.model == "itransformer")] \
                    .test_MAE.iloc[0]
                tc = df[(df.fold == f) & (df.model == "tcdpmixer")] \
                    .test_MAE.iloc[0]
                ax.text(x[k] + w, it + 4, f"−{it - tc:.1f}",
                        ha="center", color=AMBER, fontsize=9.5,
                        fontweight="bold")
            ax.set_ylim(0, max(df_w[df_w.model == "dlinear"].test_MAE) * 1.10)

    axes[0].legend(loc="upper left", frameon=False, fontsize=9.5)
    fig.suptitle("Block-CV across four chronological cuts",
                 color=INK, fontsize=13, y=1.02)
    fig.tight_layout()
    _save(fig, "fig_block_cv")
    plt.close(fig)


# ────────────────────────────────────────────────────────────
# 2) Minimal variant: full vs minimal-A vs minimal-B, per task
# ────────────────────────────────────────────────────────────
def fig_minimal():
    df_w = pd.read_csv(os.path.join(RESULTS, "minimal_weekly.csv"))
    df_s = pd.read_csv(os.path.join(RESULTS, "minimal.csv"))

    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.2))

    variants_order = ["full", "minimal_A_tc", "minimal_B_no_gate"]
    pretty = {
        "full":              "Full\nTC-DPMixer",
        "minimal_A_tc":      "Minimal-A\n(time-mixer\n+ TC gate)",
        "minimal_B_no_gate": "Minimal-B\n(time-mixer,\nno gate)",
    }
    colors = [SLATE, AMBER, TEAL]

    for ax, df, title, units in [
        (axes[0], df_w, "Weekly task ($H{=}168$)",  "Wh/h"),
        (axes[1], df_s, "Short task ($H{=}24$)",    "Wh"),
    ]:
        means, stds, params = [], [], []
        for v in variants_order:
            sub = df[df.variant == v]
            means.append(sub.test_MAE.mean())
            stds.append(sub.test_MAE.std(ddof=1))
            params.append(int(sub.params.iloc[0]))

        x = np.arange(len(variants_order))
        ax.bar(x, means, 0.55, yerr=stds, color=colors,
               edgecolor=INK, linewidth=0.5, capsize=4,
               error_kw=dict(ecolor=INK, lw=1.0))

        gap = means[0] - means[1]               # full − minimal_A
        param_drop = 100 * (1 - params[1] / params[0])
        sgn = "$-$" if gap > 0 else "$+$"
        label = (f"{sgn}{abs(gap):.2f} {units}\n"
                 f"{param_drop:.0f}% fewer params")
        ax.annotate(label,
                    xy=(1, means[1] + stds[1]),
                    xytext=(0.50, means[0] + (max(means) - min(means)) * 1.2),
                    ha="center", color=AMBER, fontsize=9,
                    arrowprops=dict(arrowstyle="->", color=AMBER, lw=1.0))

        ax.set_title(title, color=INK, fontsize=12, pad=8)
        ax.set_xticks(x)
        ax.set_xticklabels([pretty[v] for v in variants_order],
                           fontsize=9)
        ax.set_ylabel(f"Test MAE ({units})", color=INK, fontsize=10)
        lo = min(means) - max(stds) - (max(means) - min(means)) * 0.8
        hi = max(means) + (max(means) - min(means)) * 2.0
        ax.set_ylim(lo, hi)
        # params under each bar
        for i, p in enumerate(params):
            ax.text(x[i], lo + (hi - lo) * 0.04, f"{p/1000:.0f}K params",
                    ha="center", va="bottom", color=INK, fontsize=9,
                    fontweight="bold")
        _style(ax)

    fig.suptitle("Minimal variant: which branches earn their keep?",
                 color=INK, fontsize=13, y=1.02)
    fig.tight_layout()
    _save(fig, "fig_minimal")
    plt.close(fig)


if __name__ == "__main__":
    print("Plotting block-CV ...")
    fig_block_cv()
    print("Plotting minimal-variant ...")
    fig_minimal()
    print("Done.")
