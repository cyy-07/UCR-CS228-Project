"""
make_gate_figure.py — quick re-renderer for fig_gate_policy.pdf
                      reads results/gate_policy.csv, plots with serif font.

Run:  python src/make_gate_figure.py
"""
import os, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib import rcParams

INK, SLATE, AMBER, TEAL, GRID = ("#1F2A37", "#6B7C8F", "#D99A2B",
                                 "#2E8B8B", "#D7DDE3")

rcParams.update({
    "font.family":      "serif",
    "font.serif":       ["Times New Roman", "Times", "STIXGeneral",
                          "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size":        11,
    "axes.titlesize":   12,
    "axes.labelsize":   11,
    "legend.fontsize":  10,
    "savefig.dpi":      300,
    "savefig.bbox":     "tight",
})


def _style(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(SLATE)
    ax.spines["bottom"].set_color(SLATE)
    ax.tick_params(colors=INK, labelsize=10)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def render(csv_in, png_out, pdf_out, title):
    df = pd.read_csv(csv_in)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.0))
    for ax, day in zip(axes, ["weekday(Wed)", "weekend(Sun)"]):
        sub = df[df.day == day].sort_values("hour")
        ax.plot(sub.hour, sub.g_trend,
                color=AMBER, lw=2.0, label=r"$\alpha_{\mathrm{trend}}(t)$")
        ax.plot(sub.hour, sub.g_seasonal,
                color=TEAL, lw=2.0, label=r"$\alpha_{\mathrm{seasonal}}(t)$")
        ax.set_xlabel("Hour of day", color=INK)
        ax.set_ylabel("Gate value $\\alpha_k(c_t)$", color=INK)
        ax.set_title(day.replace("(", " (").replace(")", ")"),
                     color=INK)
        ax.set_xticks([0, 4, 8, 12, 16, 20, 24])
        ax.set_xlim(0, 24)
        ax.legend(loc="upper right", frameon=False)
        _style(ax)
    fig.suptitle(title, color=INK, y=1.02)
    fig.tight_layout()
    fig.savefig(png_out); fig.savefig(pdf_out)
    print(" -> " + png_out); print(" -> " + pdf_out)
    plt.close(fig)


if __name__ == "__main__":
    R = "results"
    FIG = os.path.join(R, "figures")
    render(os.path.join(R, "gate_policy.csv"),
           os.path.join(FIG, "fig_gate_policy.png"),
           os.path.join(FIG, "fig_gate_policy.pdf"),
           "TC-DPMixer gate schedule (short task, 24-h cycle)")
    if os.path.exists(os.path.join(R, "gate_policy_weekly.csv")):
        render(os.path.join(R, "gate_policy_weekly.csv"),
               os.path.join(FIG, "fig_gate_policy_weekly.png"),
               os.path.join(FIG, "fig_gate_policy_weekly.pdf"),
               "TC-DPMixer gate schedule (weekly task, 24-h cycle)")
